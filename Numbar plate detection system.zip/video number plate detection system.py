import cv2
import pytesseract
import numpy as np

# Set the Tesseract-OCR path (Update if needed)
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"

def detect_number_plate(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
    gray = cv2.GaussianBlur(gray, (5, 5), 0)  # Reduce noise
    gray = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)  # Improve contrast
    edged = cv2.Canny(gray, 50, 200)  # Apply edge detection

    # Find contours
    contours, _ = cv2.findContours(edged, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]  # Get largest contours

    for contour in contours:
        approx = cv2.approxPolyDP(contour, 0.02 * cv2.arcLength(contour, True), True)
        if len(approx) == 4:  # Check for a rectangular number plate
            x, y, w, h = cv2.boundingRect(approx)
            plate_img = frame[y:y+h, x:x+w]  # Crop the detected plate

            # Preprocess for OCR
            plate_gray = cv2.cvtColor(plate_img, cv2.COLOR_BGR2GRAY)
            plate_gray = cv2.resize(plate_gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
            plate_gray = cv2.GaussianBlur(plate_gray, (3, 3), 0)
            plate_gray = cv2.threshold(plate_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]

            # OCR with improved settings
            custom_config = r'--oem 3 --psm 8 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
            text = pytesseract.image_to_string(plate_gray, config=custom_config).strip()

            # Draw bounding box on the original image
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(frame, text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

            print("Detected Number Plate:", text)
            return frame, text  # Return frame with bounding box

    print("No number plate detected.")
    return frame, "No Plate"

# Function to process images
def process_image(image_path):
    image = cv2.imread(image_path)
    if image is None:
        print("Error: Could not load image.")
        return

    marked_image, detected_text = detect_number_plate(image)
    cv2.imshow("Number Plate Detection", marked_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print("Final Detected Plate:", detected_text)

# Function to process videos and webcam
def process_video(video_source=0):
    cap = cv2.VideoCapture(video_source)

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        marked_frame, _ = detect_number_plate(frame)
        cv2.imshow("Number Plate Detection", marked_frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

# Main function to choose mode
def main():
    mode = input("Enter mode (image, video, webcam): ").strip().lower()

    if mode == "image":
        image_path = input("Enter image path: ").strip()
        process_image(image_path)
    elif mode == "video":
        video_path = input("Enter video file path: ").strip()
        process_video(video_path)
    elif mode == "webcam":
        process_video(0)  # 0 uses the default webcam
    else:
        print("Invalid mode selected.")

if __name__ == "__main__":
    main()